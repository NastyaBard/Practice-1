﻿namespace zzz5;

public class Program
{
    static void Main()
    {
        Console.WriteLine("Введите строку: ");
        string input = Console.ReadLine();
        string[] words = input.Split(new char[] { ' ', '.', ','}); //разделяем введенную строку на слова используя знаки(создаем новый массив символов, следующий метод позволяет игнорировать повторяющиеся знаки и не учитывать их)
        Console.WriteLine($"Количество слов: {words.Length}"); //выводим кол во слов в строке
        Console.WriteLine($"Измененная строка: start {input} end"); 

    }
}