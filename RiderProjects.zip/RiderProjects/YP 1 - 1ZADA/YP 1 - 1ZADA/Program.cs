﻿
public class Program

{

    static void Main()
    {
        List<string> list = new List<string>(); //создаем новый список строк 
        Console.WriteLine("Введите элементы списка(пустая строка - завершение): ");
        while (true)
        {
            string input = Console.ReadLine();
            if (string.IsNullOrEmpty(input))
            {
                break;//если введена пустая строка завершаем цикл    
            }
            list.Add(input);//добавляем введенную строку в список
        }
        if (list.Count > 0) //если список не пустой, находим самый короткий и длинный элементы
        {
            string shortest = list[0];
            string longest = list[0];
            foreach (string element in list)
            {
                if (element.Length < shortest.Length)
                {
                    shortest = element; //самый короткий элемент
                }
                if (element.Length > shortest.Length)
                {
                    longest = element;//самый длинный элемент
                }
            }
            Console.WriteLine($"Самый короткий элемент: {shortest}");
            Console.WriteLine($"Самый длинный элемент: {longest}");
        }
        else
        {
            Console.Write("Список пуст");
        }
    }
}

