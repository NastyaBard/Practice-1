﻿namespace zz6;

public class Program
{
    static void Main()
    {
        Console.Write("Введите длину массива: ");
        int length = Convert.ToInt32(Console.ReadLine()); 
        double[] Arr = new double[length];
        Console.WriteLine($"Введите {length} дробных положительных и отрицательных чисел(ла): ");
        for (int i = 0; i < length; i++)
        {
            Arr[i] = Convert.ToDouble(Console.ReadLine()); // Считываем число отдельной строкой
        }
        // Создаем два новых массива для положительных и отрицательных чисел
        double[] positiveNumbers = Array.FindAll(Arr, x => x > 0);
        double[] negativeNumbers = Array.FindAll(Arr, x => x < 0);
        Console.WriteLine("Массив положительных чисел:");
        foreach (var number in positiveNumbers)
        {
            Console.Write($"{number} ");
        }
        Console.WriteLine("\nМассив отрицательных чисел:");
        foreach (var number in negativeNumbers)
        {
            Console.Write($"{number} ");
        }
    }
}