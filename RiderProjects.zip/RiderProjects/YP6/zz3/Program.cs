﻿namespace zz3;

public class Program
{
    static void Main()
    {
        Console.Write("Введите число: ");
        int number = Convert.ToInt32(Console.ReadLine());
        if (number % 2 == 0 && number % 10 == 0)
        {
            Console.Write($"Число {number} является четным и кратным 10");
        }
        else
        {
            Console.Write($"Число {number} не является четным и кратным 10");
        }
    }
}