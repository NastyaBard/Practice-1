﻿namespace zz2;

public class Program
{
    static void Main()
    {
        string content = File.ReadAllText("numsTask2.txt"); // Считываем все содержимое файла 
        string[] words = content.Split(new char[] { '\n', '\r' }); // Разделяем содержимое на отдельные слова, учитывая символы новой строки 
        string result = string.Join(" ", words); // Составляем одну длинную строку, разделяя каждое слово пробелом
        Console.WriteLine(result); 
    }
}