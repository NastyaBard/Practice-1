﻿namespace YP6;

public class Program
{
    static void Main()
    {
        string[] words; // Создаем массив строк для хранения слов из файла
        string content = File.ReadAllText("numsTask1.txt"); // Считываем все содержимое файла
        words = content.Split(new char[] {' '}); // Разбиваем содержимое на отдельные слова
        foreach (string word in words) // Проходим по каждому слову и выводим те, у которых длина нечетная
        {
            if (word.Length % 2 != 0)
            {
                Console.WriteLine($"Слово имеющее нечетную длину: {word}");
            }
        }
    }
}