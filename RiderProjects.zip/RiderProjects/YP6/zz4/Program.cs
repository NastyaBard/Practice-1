﻿namespace zz4;

public class Program
{
    static void Main()
    {
        int sum = 0; 
        Console.Write("Введите a: ");
        int a = Convert.ToInt32(Console.ReadLine()); 
        Console.WriteLine("Введите положительные числа. Для завершения введите отрицательное число: ");
        while (true) // Запускаем бесконечный цикл
        {
            int number = Convert.ToInt32(Console.ReadLine());
            if (number < 0) // Проверяем, является ли число отрицательным
            {
                break; 
            }
            if (number % a == 0) // Проверяем, делится ли число нацело на значение a
            {
                sum += number; 
            }
        }
        Console.WriteLine($"Сумма чисел, делящихся на {a} нацело: {sum}"); 
    }
}