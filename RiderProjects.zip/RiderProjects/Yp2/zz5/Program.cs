﻿namespace zz5;

public class Program
{
    static void Main()
    {
        string[] month = {"Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль","Август","Сентябрь","Октябрь","Ноябрь", "Декабрь" };
        Dictionary<string, double[]> temperatureDictionary = new Dictionary<string, double[]>();

        Random random = new Random();
        for (int i = 0; i < 12; ++i) 
        {
            double[] daily = new double[30];
            for (int j = 0; j < 30; ++j) 
            {
                daily[j] = random.Next(-35, 40);
            }
            temperatureDictionary.Add(month[i], daily);
        }

        Dictionary<string, double> average = CalculateAverageTemperature(temperatureDictionary);

        foreach (var kvp in average)
        {
            Console.WriteLine($"Средняя температура за {kvp.Key}: {Math.Round(kvp.Value, 2)} С");
        }
    }
    static Dictionary<string, double> CalculateAverageTemperature(Dictionary<string, double[]> temperatures)
    {
        Dictionary<string, double> average = new Dictionary<string, double>();

        foreach (var kvp in temperatures)
        {
            double sum = 0;
            foreach (var temp in kvp.Value)
            {
                sum += temp;
            }
            average.Add(kvp.Key, sum / kvp.Value.Length);
        }

        return average;
    }
}
