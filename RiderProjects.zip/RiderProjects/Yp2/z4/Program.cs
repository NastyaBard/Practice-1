﻿namespace z4;

public class Program
{
    static void Main()
    {
        string[] month = {"Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль","Август","Сентябрь","Октябрь","Ноябрь", "Декабрь" };
        double[,] temperatures = new double[12, 30]; //создаем массив для хранения температур
        Random random = new Random();
        for (int i = 0; i < 12; ++i) //месяца
        {
            for (int j = 0; j < 30; ++j) //дни месяца
            {
                temperatures[i, j] = random.Next(-35, 40);//генерируем случайные значения температур в диапазоне
            }
        }
        double[] average = new double[12];
        for (int i = 0; i < 12; ++i)
        {
            double sum = 0;
            for (int j = 0; j < 30; ++j)
            {
                sum += temperatures[i, j];//суммируем все температуры на протяжении 30 дней чтобы потом получить среднее
            }

            average[i] = sum / 30; // средняя температура за месяц
        }
        Array.Sort(average);
        for (int i = 0; i < 12; ++i)
        {
            Console.WriteLine($"Средняя температура за {month[i]}: {Math.Round(average[i],2)} С"); //выводим и округяем до сотых 
        }
    }
}
