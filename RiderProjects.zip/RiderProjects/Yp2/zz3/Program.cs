﻿namespace zz3;

public class Program
{
    static void Main()
    {
        Console.Write("Введите размерность матрицы: ");
        int n = Convert.ToInt32(Console.ReadLine());
        int[,] Arr = new int[n, n];
        for (int i = 0; i < n; ++i)
        {
            Arr[0, i] = 1;
            Arr[i, 0] = 1; //заполняем первую строку и первый столбец единицами
        }
        for (int i = 1; i < n; ++i)
        {
            for (int j = 1; j < n; ++j)
            {
                Arr[i, j] = Arr[i - 1, j] + Arr[i, j - 1];
            }
        }

        for (int i = 0; i < n; ++i)
        {
            for (int j = 0; j < n; ++j)
            {
                Console.Write($"{Arr[i,j]} ");
            }
            Console.WriteLine();
        }
    }
}