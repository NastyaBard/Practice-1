﻿namespace Yp2;

public class Program
{
    static void Main()
    {
        int[] Arr = new int[100];
        Console.Write("Введите начальный номер последовательности: ");
        int startingNumber = Convert.ToInt32(Console.ReadLine()); 
        for (int i = 0; i < 100; i++)
        {
            Arr[i] = startingNumber;
            startingNumber -= 3;
        }

        foreach (var number in Arr)
        {
            Console.Write($"{number} ");
        }
    }
}