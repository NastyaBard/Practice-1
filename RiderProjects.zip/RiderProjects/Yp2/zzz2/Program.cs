﻿namespace zzz2;

public class Program
{
    static void Main()
    {
        Console.Write("Введите размер массива: ");
        int size = Convert.ToInt32(Console.ReadLine());
        int[] Arr = new int[size];
        int odd = 1; // Начальное нечетное число
        for (int i = 0; i < size; i++)
        {
            Arr[i] = odd;
            odd += 2; // Увеличиваем на 2 для получения следующего нечетного числа
        }
        foreach (var number in Arr)
        {
            Console.Write($"{number} ");
        }
    }
}
