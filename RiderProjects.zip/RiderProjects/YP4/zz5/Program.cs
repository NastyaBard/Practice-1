﻿namespace zz5;

public class Program
{
  static void Main()
  {
    Console.Write("Введите координату x: ");
    double x = Convert.ToDouble(Console.ReadLine());
    Console.Write("Введите координату y: ");
    double y = Convert.ToDouble(Console.ReadLine());
   if (x >= -0.9 && x <= 2.9 && y >= -1.75 && y <= 4.0)
    {
      Console.WriteLine($"Точка с координатами ({x};{y}) принадлежит квадрату.");
    }
    else
    {
      Console.WriteLine($"Точка с координатами ({x};{y}) не принадлежит квадрату.");
    }
  }
}
