﻿namespace YP4;

public class Program
{
    static void Main()
    {
        Console.Write("Введите целое положительное число: ");
        int n = Convert.ToInt32(Console.ReadLine());
        int c = 1;
        for (int i = 3; i <= n; i += 3) // учитываем только числа кратные 3
        {
            c *= i;
        }

        Console.WriteLine($"Произведение натуральных чисел, кратных трём и не превышающих число n: {c} ");
    }
}
