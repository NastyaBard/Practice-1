﻿namespace zz6;

public class Program
{
    static void Main()
    {
        Console.Write("Введите координату a(x): ");
        double x = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите координату b(y): ");
        double y = Convert.ToDouble(Console.ReadLine());
        if (x >= -2 && x <= 2 && y >= -3 && y <= 2 && x == 0)
        {
            Console.WriteLine($"Точка с координатами ({x};{y}) принадлежит треугольнику.");
        }
        else
        {
            Console.WriteLine($"Точка с координатами ({x};{y}) не принадлежит треугольнику.");
        }
    }
}     