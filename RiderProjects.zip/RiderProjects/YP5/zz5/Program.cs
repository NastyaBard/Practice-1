﻿namespace zz5;

public class Program
{
    static void Main()
    {
        string[] nums = File.ReadAllText("numsTask5.txt").Split(' '); // Считываем все числа из файла в массив строк
        int[] numbers = Array.ConvertAll(nums, int.Parse); // Преобразуем строки в массив целых чисел
        int min = numbers.Min(); // Находим минимальное число в массиве
        int max = numbers.Max(); // Находим максимальное число в массиве
        var elementsInRange = numbers.Where(num => num > min && num < max).ToArray();// Находим элементы, которые больше минимального и меньше максимального
        double average = elementsInRange.Average();  // Вычисляем среднее арифметическое элементов, расположенных между минимальным и максимальным
        Console.WriteLine($"Среднее арифметическое элементов между минимальным: {average}");
    }
}