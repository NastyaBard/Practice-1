﻿namespace YP5;

public class Program
{
    static void Main()
    {
        string[] nums = File.ReadAllText("numsTask1.txt").Split(' ');// Считываем все числа из файла в массив строк
        int[] numbers = Array.ConvertAll(nums, Convert.ToInt32);  // Преобразуем строки в массив целых чисел
        int minNumber = numbers.Min();// Находим минимальное число в массиве
        int minIndex = Array.IndexOf(numbers, minNumber); // Находим индекс минимального числа
        int product = 1; // Если минимальное число находится в конце массива, то произведение будет 1
        if (minIndex < numbers.Length - 1)// Если минимальное число не находится в конце массива, вычисляем произведение элементов после минимального числа
        {
            for (int i = minIndex + 1; i < numbers.Length; i++)// Вычисляем произведение элементов после минимального числа
            {
                product *= numbers[i];
            }
        }
        Console.WriteLine($"Произведение элементов после минимального числа: {product}");
    }
}
    