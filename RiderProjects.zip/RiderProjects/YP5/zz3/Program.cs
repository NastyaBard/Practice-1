﻿namespace zz3;

public class Program
{
    static void Main()
    {
        string[] nums = File.ReadAllText("numsTask3.txt").Split(' ');
        int[] numbers = Array.ConvertAll(nums, Convert.ToInt32);

        int minNumber = numbers.Min();
        int minIndex = Array.IndexOf(numbers, minNumber);

        if (minIndex == 0)
        {
            Console.WriteLine("Минимальное число находится первым, невозможно вычислить среднее арифметическое элементов до него.");
        }
        else
        {
            double average = numbers.Take(minIndex).Average();
            Console.WriteLine($"Среднее арифметическое элементов до минимального числа: {average}");
        } 
    }
}