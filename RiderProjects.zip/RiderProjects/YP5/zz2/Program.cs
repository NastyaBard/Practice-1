﻿
namespace zz2;

public class Program
{
    static void Main()
    {
        string[] nums = File.ReadAllText("numsTask2.txt").Split(';'); // Считываем числа из файла и разделяем их по символу ';'

        SortAscending(nums); // Вызываем метод для сортировки по возрастанию

        string result = string.Join(";", nums); // Объединяем отсортированные числа в строку с разделителем ';'
        File.WriteAllText("numsTask2.txt", result); // Записываем отсортированные числа обратно в файл
    } 

    static void SortAscending(string[] array) 
    {
        Array.Sort(array, (x, y) => double.Parse(x).CompareTo(double.Parse(y))); // Используем встроенную функцию сортировки
    }
}