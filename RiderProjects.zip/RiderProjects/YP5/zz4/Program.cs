﻿namespace zz4;
public class Program
{
    static void Main()
    {
        {
            string[] num = File.ReadAllText("numsTask4.txt").Split(' ');
            int[] numbers = Array.ConvertAll(num, int.Parse);
            int maxNumber = numbers.Max(); // Находим максимальное число в массиве
            int incrementedNumber = maxNumber + 1;
            int decrementedNumber = maxNumber - 1;
            int sum = incrementedNumber + decrementedNumber;
            Console.WriteLine($"Сумма элементов, отличающихся от максимального числа на 1: {sum}");
        }
    }
}
