﻿namespace zz2;

public class Program
{
    static void Main()
    {
        string[] lines = File.ReadAllText("nums.txt").Split(' ');// Читаем содержимое файла
        //Сортируем числа
        string[] oddNumbers = lines.Where(line =>
        {
            int number;
            bool isNumber = Int32.TryParse(line, out number);
            return !isNumber || number % 2 != 0;
        }).ToArray();

        // Записываем в файл нечетные числа и строки которые не являются числами
        File.WriteAllText("nums.txt", string.Join(" ", oddNumbers));
    }
}
    
