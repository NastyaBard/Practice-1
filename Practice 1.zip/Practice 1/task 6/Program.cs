namespace task_6;

public class Program
{
    //1
    /*static void Main()
    {
        string[] words; // Создаем массив строк для хранения слов из файла
        string content = File.ReadAllText("numsTask1.txt"); // Считываем все содержимое файла
        words = content.Split(new char[] {' '}); // Разбиваем содержимое на отдельные слова
        foreach (string word in words) // Проходим по каждому слову и выводим те, у которых длина нечетная
        {
            if (word.Length % 2 != 0)
            {
                Console.WriteLine($"Слово имеющее нечетную длину: {word}");
            }
        }
    }*/

    //2
    
   /* static void Main()
    {
        string content = File.ReadAllText("numsTask2.txt"); // Считываем все содержимое файла 
        string[] words = content.Split(new char[] { '\n', '\r' }); // Разделяем содержимое на отдельные слова, учитывая символы новой строки 
        string result = string.Join(" ", words); // Составляем одну длинную строку, разделяя каждое слово пробелом
        Console.WriteLine(result); 
    }*/

   //3
   
   /*static void Main()
   {
       Console.Write("Введите число: ");
       int number = Convert.ToInt32(Console.ReadLine());
       if (number % 2 == 0 && number % 10 == 0)
       {
           Console.Write($"Число {number} является четным и кратным 10");
       }
       else
       {
           Console.Write($"Число {number} не является четным и кратным 10");
       }
   }*/

   //4
   
   /*static void Main()
   {
       int sum = 0; 
       Console.Write("Введите a: ");
       int a = Convert.ToInt32(Console.ReadLine()); 
       Console.WriteLine("Введите положительные числа. Для завершения введите отрицательное число: ");
       while (true) // Запускаем бесконечный цикл
       {
           int number = Convert.ToInt32(Console.ReadLine());
           if (number < 0) // Проверяем, является ли число отрицательным
           {
               break; 
           }
           if (number % a == 0) // Проверяем, делится ли число нацело на значение a
           {
               sum += number; 
           }
       }
       Console.WriteLine($"Сумма чисел, делящихся на {a} нацело: {sum}"); 
   }*/
   
   //5
   
   /*static void Main()
   {
       Console.Write("Введите количество строк матрицы: ");
       int n = Convert.ToInt32(Console.ReadLine());
       Console.Write("Введите количество столбцов матрицы: ");
       int m  = Convert.ToInt32(Console.ReadLine()); 
       int[,] a = new int[n, m]; // Исходная матрица
       int[,] result = new int[n, m + 1]; // Матрица с дополнительным столбцом
       Random random = new Random();
       for (int i = 0; i < n; i++) // Заполнение матрицы
       {
           for (int j = 0; j < m; j++)
           {
               a[i, j] = random.Next(0, 2);
           }
       }
       for (int i = 0; i < n; i++) // Копирование исходной матрицы в новую
       {
           for (int j = 0; j < m; j++)
           {
               result[i, j] = a[i, j];
           }
       }
        
       for (int i = 0; i < n; i++)  // Добавление нового столбца
       {
           int count = 0; // Подсчет количества единиц в строке
           for (int j = 0; j < m; j++)
           {
               if (a[i, j] == 1)
               {
                   count++;
               }
           }
           result[i, m] = count % 2 == 0 ? 0 : 1;// Делаем количество единиц в каждой строке четным
       }
       Console.WriteLine("Исходная матрица:"); // Вывод исходной матрицы
       for (int i = 0; i < n; i++)
       {
           for (int j = 0; j < m; j++)
           {
               Console.Write($"{a[i, j]} ");
           }
           Console.WriteLine();
       }
       Console.WriteLine("Mатрица с дополнительным столбцом:");// Вывод новой матрицы
       for (int i = 0; i < n; i++)
       {
           for (int j = 0; j < m + 1; j++)
           {
               Console.Write($"{result[i, j]} ");
           }
           Console.WriteLine();
       }
   }*/
   
   //6
   
   static void Main()
   {
       Console.Write("Введите длину массива: ");
       int length = Convert.ToInt32(Console.ReadLine()); 
       double[] Arr = new double[length];
       Console.Write("Введите максимальное значение для генерации отрицательных дробных чисел: ");
       double Negative = Convert.ToDouble(Console.ReadLine());
       Console.Write("Введите минимальное значение для генерации положительных дробных чисел: ");
       double Positive = Convert.ToDouble(Console.ReadLine());
        
       Random random = new Random();
       for (int i = 0; i < length; i++)
       {
           if (i % 2 == 0) // Четные индексы для отрицательных чисел
           {
               Arr[i] = -1 * (random.NextDouble() * Negative);
           }
           else // Нечетные индексы для положительных чисел
           {
               Arr[i] = random.NextDouble() * Positive;
           }
       }
       double[] positiveNumbers = Array.FindAll(Arr, x => x > 0);
       double[] negativeNumbers = Array.FindAll(Arr, x => x < 0);
       Console.WriteLine("Массив положительных чисел:");
       foreach (var number in positiveNumbers)
       {
           Console.Write($"{Math.Round(number,4)} ");
       }

       Console.WriteLine("\nМассив отрицательных чисел:");
       foreach (var number in negativeNumbers)
       {
           Console.Write($"{Math.Round(number,4)} ");
       }
   }

}