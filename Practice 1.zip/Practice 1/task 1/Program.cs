namespace Practice_1;

public class Program
{
    //1.

   /* static void Main()
    {
        int[] num = new int[10];
        Random random = new Random(); // Создаем для генерации случайных чисел
        for (int i = 0; i < 10; ++i)
        {
            num[i] = random.Next(1, 1000); // генерация случайных чисел от 1 до 1000 
        }

        int min = 0;
        for (int i = 1; i < 10; ++i)
        {
            if (num[i] < num[min]) // проверяем является ли текущий элемент минимальным
            {
                min = i; // обновляем номер если найден более маленький элемент  
            }
        }

        Console.Write("Сгенерированный массив: ");
        for (int i = 0; i < 10; ++i)
        {
            Console.Write(num[i] + " ");
        }

        Console.Write($"\nНомер минимального элемента: {min}");
    }*/
//2.

   /* static void Main()
    {
        int input; // введенное пользователем число
        int sum = 0;
        int product = 1; // Произведение чисел
        int count = 0; // кол во введенных чисел
        Console.WriteLine("Введите числа через пробел(Для завершения программы введите 0): ");
        do
        {
            input = Convert.ToInt32(Console.ReadLine());
            if (input != 0)
            {
                sum += input; //суммируем числа
                product *= input; //перемножаем числа
                ++count;
            }
        } while (input != 0); // вводим числа пока не окажется 0

        double
            average = count > 0 ? (double)sum / count : 0; //Находим среднее значение, при этом запрещаем деление на 0
        Console.WriteLine($"Сумма всех элементов списка: {sum}");
        Console.WriteLine($"Произведение всех элементов списка: {product}");

        Console.WriteLine($"Среднее значение: {average}");
    }*/

//3.
   /* static void Main()
    {
        List<string> list = new List<string>(); //создаем новый список строк 
        Console.WriteLine("Введите элементы списка(пустая строка - завершение): ");
        while (true)
        {
            string input = Console.ReadLine();
            if (string.IsNullOrEmpty(input))
            {
                break; //если введена пустая строка завершаем цикл    
            }

            list.Add(input); //добавляем введенную строку в список
        }

        if (list.Count > 0) //если список не пустой, находим самый короткий и длинный элементы
        {
            string shortest = list[0];
            string longest = list[0];
            foreach (string element in list)
            {
                if (element.Length < shortest.Length)
                {
                    shortest = element; //самый короткий элемент
                }

                if (element.Length > shortest.Length)
                {
                    longest = element; //самый длинный элемент
                }
            }

            Console.WriteLine($"Самый короткий элемент: {shortest}");
            Console.WriteLine($"Самый длинный элемент: {longest}");
        }
        else
        {
            Console.Write("Список пуст");
        }
    }*/


//4.

    /*static void Main()
    {
        Console.Write("Введите начало диапазона: ");
        int start = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите конец диапазона: ");
        int end = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите размер массива: ");
        int size = Convert.ToInt32(Console.ReadLine()); // Пользователь вводит размер массива
        int[] randomNumbers = GenerateRandomNumbers(start, end, size); // Генерируем массив случайных чисел
        PrintArray(randomNumbers); // Выводим элементы массива в одну строку через пробел
    }

    static int[] GenerateRandomNumbers(int start, int end, int size)
    {
        int[] numbers = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++)
        {
            int randomNumber = random.Next(start, end + 1);
            numbers[i] = randomNumber;
        }

        return numbers;
    }

    static void PrintArray(int[] arr)
    {
        foreach (var num in arr)
        {
            Console.Write(num + " ");
        }
    }*/
    
        static void Main()
        {
            Console.WriteLine("Введите строку: ");
            string input = Console.ReadLine();
            string[] words = input.Split(new char[] { ' ', '.', ','}); //разделяем введенную строку на слова используя знаки(создаем новый массив символов, следующий метод позволяет игнорировать повторяющиеся знаки и не учитывать их)
            Console.WriteLine($"Количество слов: {words.Length}"); //выводим кол во слов в строке
            Console.WriteLine($"Измененная строка: start {input} end"); 

        }
    

}

