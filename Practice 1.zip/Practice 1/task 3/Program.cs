namespace task_3;

public class Program
{
    //1
    /*static void Main()
    {
        string inputFile = "input.txt";
        string outputFile = "output.txt";
        string inputText = File.ReadAllText(inputFile);
        string[] lines = inputText.Split(Environment.NewLine);
        string[] winningNumbers = lines[0].Split(" "); 
        List<string[]> ticketNumbers = new List<string[]>();
        for (int i = 2; i < lines.Length; i++)
        {
            ticketNumbers.Add(lines[i].Split(" "));
        }

        List<string> outputs = new List<string>();
        foreach (string[] ticketNumber in ticketNumbers)
        {
            int winningTicket = 0;
            foreach (string number in ticketNumber)
            {
                if (winningNumbers.Contains(number))
                {
                    winningTicket++;
                }
            }
            string output = (winningTicket >= 3) ? "Lucky" : "Unlucky";
            Console.WriteLine(output);
            outputs.Add(output);
        }

        File.WriteAllLines(outputFile, outputs);
    }*/
    //2
       /* static void Main()
        {
            string[] lines = File.ReadAllText("nums.txt").Split(' ');// Читаем содержимое файла
            //Сортируем числа
            string[] oddNumbers = lines.Where(line =>
            {
                int number;
                bool isNumber = Int32.TryParse(line, out number);
                return !isNumber || number % 2 != 0;
            }).ToArray();

            // Записываем в файл нечетные числа и строки которые не являются числами
            File.WriteAllText("nums.txt", string.Join(" ", oddNumbers));
        }*/
       //3
       
           static void Main()
           {
               string fileContent = File.ReadAllText("input2.txt");
               string[] parts = fileContent.Split('{', '}', ',', '=', ' ');
               int[] height = parts.Where(s => int.TryParse(s, out _)).Select(int.Parse).ToArray();
               int maxArea = 0;
               int left = 0;
               int right = height.Length - 1;
               while (left < right)
               {
                   int currentArea = (right - left) * Math.Min(height[left], height[right]);
                   maxArea = Math.Max(maxArea, currentArea);
                   if (height[left] < height[right])
                   {
                       left++;
                   }
                   else
                   {
                       right--;
                   }
               }
               Console.WriteLine($"Максимальная площадь, которую можно заполнить водой: {maxArea}");
           }
}

