namespace task_2;

public class Program
{
    //1.
    
    /*static void Main()
    {
        int[] Arr = new int[100];
        Console.Write("Введите начальный номер последовательности: ");
        int startingNumber = Convert.ToInt32(Console.ReadLine()); 
        for (int i = 0; i < 100; i++)
        {
            Arr[i] = startingNumber;
            startingNumber -= 3;
        }

        foreach (var number in Arr)
        {
            Console.Write($"{number} ");
        }
    }*/


//2.
   /*static void Main()
    {
        Console.Write("Введите размер массива: ");
        int size = Convert.ToInt32(Console.ReadLine());
        int[] Arr = new int[size];
        int odd = 1; // Начальное нечетное число
        for (int i = 0; i < size; i++)
        {
            Arr[i] = odd;
            odd += 2; // Увеличиваем на 2 для получения следующего нечетного числа
        }
        foreach (var number in Arr)
        {
            Console.Write($"{number} ");
        }
    }*/
//3.
    /*static void Main()
    {
        Console.Write("Введите размерность матрицы: ");
        int n = Convert.ToInt32(Console.ReadLine());
        int[,] Arr = new int[n, n];
        for (int i = 0; i < n; ++i)
        {
            Arr[0, i] = 1;
            Arr[i, 0] = 1; //заполняем первую строку и первый столбец единицами
        }
        for (int i = 1; i < n; ++i)
        {
            for (int j = 1; j < n; ++j)
            {
                Arr[i, j] = Arr[i - 1, j] + Arr[i, j - 1];
            }
        }

        for (int i = 0; i < n; ++i)
        {
            for (int j = 0; j < n; ++j)
            {
                Console.Write($"{Arr[i,j]} ");
            }
            Console.WriteLine();
        }
    }*/


//4.
    /*static void Main()
    {
        string[] month = {"Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль","Август","Сентябрь","Октябрь","Ноябрь", "Декабрь" };
        double[,] temperatures = new double[12, 30]; //создаем массив для хранения температур
        Random random = new Random();
        for (int i = 0; i < 12; ++i) //месяца
        {
            for (int j = 0; j < 30; ++j) //дни месяца
            {
                temperatures[i, j] = random.Next(-35, 40);//генерируем случайные значения температур в диапазоне
            }
        }
        double[] average = new double[12];
        for (int i = 0; i < 12; ++i)
        {
            double sum = 0;
            for (int j = 0; j < 30; ++j)
            {
                sum += temperatures[i, j];//суммируем все температуры на протяжении 30 дней чтобы потом получить среднее
            }

            average[i] = sum / 30; // средняя температура за месяц
        }
        Array.Sort(average);
        for (int i = 0; i < 12; ++i)
        {
            Console.WriteLine($"Средняя температура за {month[i]}: {Math.Round(average[i],1)} С"); //выводим и округяем до сотых 
        }
    }*/


//5.
    static void Main()
    {
        string[] month = {"Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль","Август","Сентябрь","Октябрь","Ноябрь", "Декабрь" };
        Dictionary<string, double[]> temperatureDictionary = new Dictionary<string, double[]>();

        Random random = new Random();
        for (int i = 0; i < 12; ++i) 
        {
            double[] daily = new double[30];
            for (int j = 0; j < 30; ++j) 
            {
                daily[j] = random.Next(-35, 40);
            }
            temperatureDictionary.Add(month[i], daily);
        }

        Dictionary<string, double> average = CalculateAverageTemperature(temperatureDictionary);

        foreach (var kvp in average)
        {
            Console.WriteLine($"Средняя температура за {kvp.Key}: {Math.Round(kvp.Value, 2)} С");
        }
    }

    static Dictionary<string, double> CalculateAverageTemperature(Dictionary<string, double[]> temperatures)
    {
        Dictionary<string, double> average = new Dictionary<string, double>();

        foreach (var kvp in temperatures)
        {
            double sum = 0;
            foreach (var temp in kvp.Value)
            {
                sum += temp;
            }
            average.Add(kvp.Key, sum / kvp.Value.Length);
        }

        return average;
    }
}