namespace task_4;

public class Program
{
        //1
        /*static void Main()
        {
            Console.Write("Введите целое положительное число: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int c = 1;
            for (int i = 3; i <= n; i += 3) // учитываем только числа кратные 3
            {
                c *= i;
            }

            Console.WriteLine($"Произведение натуральных чисел, кратных трём и не превышающих число n: {c} ");
        }*/
        
        //2
           /* static void Main()
            {
                string[] nums = File.ReadAllText("numsTask2.txt").Split(';'); //разделяем числа по ;
                double sum = 0;
                foreach (string num in nums) //перебираем все числа в массиве 
                { 
                    double n = Convert.ToDouble(num); 

                    if (n > 0 || n == 0)  //если число больше или равно 0 добавляем к сумме
                    { 
                        sum += n; 
                    }
                } 

                Console.WriteLine($"Сумма положительных чисел до 0: {sum}"); 
            }*/
           
           //3
          /* static void Main()
           {
               string[] Arr = File.ReadAllText("numsTask3.txt").Split(',');
               int[] numbers = Array.ConvertAll(Arr, Convert.ToInt32); //преобразуем строки в массив целых чисел

               int min = numbers[0];
               int max = numbers[0];
               foreach (int num in numbers)
               {
                   if (num == 0)
                   {
                       break;
                   }
                   if (num < min)
                   {
                       min = num;
                   }
                   if (num > max)
                   {
                       max = num;
                   }
               }

               if (min != 0 && max != 0) 
               {
                   double ratio = (double)min / max;
                   Console.WriteLine($"Отношение минимального к максимальному: {ratio}");
               }
        
           }*/

          //4
          
         /* static void Main()
          {
              string[] numbers = File.ReadAllText("numsTask4.txt").Split(' ');
              int count = 1; // Начальное количество одинаковых рядом стоящих чисел
              for (int i = 1; i < numbers.Length; ++i)
              {
                  if (numbers[i] == numbers[i - 1]) // Если текущее число равно предыдущему
                  {
                      ++count; 
                  }
              }
              Console.WriteLine($"Количество одинаковых рядом стоящих чисел: {count + 1}"); // Выводим количество для последней последовательности 
          }*/
         
         //5
         
         /*static void Main()
         {
             Console.Write("Введите координату a(x): ");
             double x = Convert.ToDouble(Console.ReadLine());
             Console.Write("Введите координату b(y): ");
             double y = Convert.ToDouble(Console.ReadLine());
             if (x >= -2 && x <= 2 && y >= -3 && y <= 2 && x == 0)
             {
                 Console.WriteLine($"Точка с координатами ({x};{y}) принадлежит треугольнику.");
             }
             else
             {
                 Console.WriteLine($"Точка с координатами ({x};{y}) не принадлежит треугольнику.");
             }
         }*/
         
         //6
         
         static void Main()
         {
             Console.Write("Введите координату a(x): ");
             double x = Convert.ToDouble(Console.ReadLine());
             Console.Write("Введите координату b(y): ");
             double y = Convert.ToDouble(Console.ReadLine());
             if (x >= -2 && x <= 2 && y >= -3 && y <= 2 && x == 0)
             {
                 Console.WriteLine($"Точка с координатами ({x};{y}) принадлежит треугольнику.");
             }
             else
             {
                 Console.WriteLine($"Точка с координатами ({x};{y}) не принадлежит треугольнику.");
             }
         }


    
}